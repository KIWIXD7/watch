<?php
function component($p_name,$p_price,$p_image,$p_id)
{
    $products ="
    <div class='col-md-3 col-sm-6 my-3 my-md-0'>
    <form action='/Watch/index.php' method='post'>
      <div class='card shadow'>
        <div>
        <a href='/Watch/product_buy.php?id=$p_id'><img src='$p_image' alt='img'  height='200px' width='250px' /></a>
        </div>
        <div class='card-body'>
          <h5 class='card-title'>$p_name</h5>
          <h6>
            <i class='fas fa-star'></i>
            <i class='fas fa-star'></i>
            <i class='fas fa-star'></i>
            <i class='fas fa-star'></i>
            <i class='far fa-star'></i>
          </h6>
          
          <h5>
            <small><s class='text-secondary'>$799</s></small>
            <span class='price'>$$p_price</span>
            
          </h5>
          
          <button type='submit' class='btn btn-warning' name='add'><i class='fas fa-shopping-cart'></i>Add to Cart</button>
          <input type='hidden' name='c_id' value='$p_id'>
        </div>
      </div>
    </form>
  </div><br>";

    echo $products;
}

function add_cart_show($p_img,$p_name,$p_price,$p_id)
{
    $cart ="
    <form action='/Watch/add_to_cart.php?action=remove&id=$p_id' method='post' class='cart-items'>
    <div class='border rounded'>
        <div class='row bg-white'>
            <div class='col-md-3 pl-0'>
                <img src='$p_img' alt='test' class='img-fluid'>
            </div>
            <div class='col-md-6'>
                <h5 class='pt-2'>$p_name</h5>
                <small class='text-secondary'>Sellr:</small>
                <h5 class='pt-2'>$$p_price</h5>
                <a href='product_buy.php?id=$p_id'><button type='button' class='btn btn-primary'>Buy</button></a>
                <button type='submit' class='btn btn-danger mx-2' name='remove'>Remove</button>
            </div>
            <div class='col-md-3'><!--py-5-->
                <div>
                <input type='text' value='1' class='form-control w-25 d-inline'>
                </div>
                
                </div>
                </div>
                </div>
                </form>   
                
                ";
                // <button type='button' class='btn bg-light border rounded-circle'><i class='fas fa-minus'></i></button>
    // <button type='button' class='btn bg-light border rounded-circle'><i class='fas fa-plus'></i></button>
    echo $cart;
}

function get_category($name,$image,$c_id)
{
  
    $cat = "<div class='col-md-3 col-sm-6 my-3 my-md-0'>
    <form action='menus/categries.php' method='post'>
      <div class='card shadow'>
        
        <div>
        <a href='show_category.php?id=$c_id'><img src='$image' alt='img' height='200px' width='250px';/></a>
        <br><br>
        <h2>$name</h2>
        </div>
        <div>
          <input type='hidden' name='c_id' value='$c_id'>
        </div>
      </div>
    </form>
  </div>";
    echo $cat;
}


?>