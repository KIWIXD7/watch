<?php
session_start();
  require 'database/dbconnect.php';
  
if(isset($_SESSION['login']) && $_SESSION['login'] == true)
{
    $login = true;
}
else
{
    $login = false;
}  



require('header.php');


?>


<br><br>
<section class="contact_section ">
    <div class="container px-0">
      <div class="heading_container ">
        <h2 class="">
          Contact Us
        </h2>
      </div>
    </div>
    <div class="container container-bg">
      <div class="row">
        
        <div class="col-md-9 col-lg-10 px-0">
          <form action="contact.php" method="post">
            <div>
              <input type="text" placeholder="Enter Full Name" name="fname" require/>
            </div>
            <div>
              <input type="email" placeholder="Enter Email" name="email" require/>
            </div>
            <div>
              <input type="text" placeholder="Enter Phone" name="phone" require/>
            </div>
            <div>
            <textarea class="textarea" name="message" rows="6" colms="10" placeholder="Message"></textarea>
            </div>
            <div class="d-flex">
            <button class="send" type="submit" name="submit">Send</button><br>
            </div>              
          </form>
        </div>
      </div>
    </div>
  </section>
  <br><br>
<?php require('footer.php');?>

<?php
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
 
   $name = $_POST['fname'];
   $email = $_POST['email'];
   $phone = $_POST['phone'];
   $message = $_POST['message'];
 
   if (isset($_POST['submit'])) 
   {
      if ($login == true) {
         if ($_SESSION['user'] == $name)
          {
            if ($name == !"" && $email == !"" && $phone == !"" && $message == !"") 
            {
               $query_insert = "INSERT INTO `contact` (`username`, `email`, `number`, `message`, `date`) VALUES ('$name', '$email', '$phone', '$message', current_timestamp());";
               $run_query = mysqli_query($conn, $query_insert);
              echo "<script>alert('Your Feedback is Sending')</script>";
            }
            else
          {
              echo "<script>alert('Your Data is Empty || Enter Your FeedBack')</script>";
          }
       }
        else
         {
              echo "<script>alert('Your Username is Not Exist Check Your Usename')</script>";
         }
     }
      else 
      {
         echo "<script>alert('You are not login || to login in website')</script>";
         //echo"<a href='/project/login.php'>Click Login</a>";
     }
   }
 }
?>