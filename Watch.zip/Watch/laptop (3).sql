-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2023 at 05:03 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laptop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `adminname` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `adminname`, `password`) VALUES
(1, 'admin', '123');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `image` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `image`, `date`) VALUES
(1, 'HP', '/laptop/images/hp1.jpg', '2023-09-11 19:58:22'),
(2, 'Dell', '/laptop/images/dell1.jpg', '2023-09-11 20:01:14');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(40) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `username`, `email`, `number`, `message`, `date`) VALUES
(1, 'yuvraj', 'yuvraj@gmail.com', '9595945678', 'hello', '2023-09-17 12:40:38');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `p_id` int(30) NOT NULL,
  `user_id` int(20) NOT NULL,
  `pro_name` varchar(200) NOT NULL,
  `pro_image` varchar(100) NOT NULL,
  `pro_price` int(40) NOT NULL,
  `user_name` varchar(30) NOT NULL,
  `number` varchar(12) NOT NULL,
  `address` varchar(40) NOT NULL,
  `city` varchar(30) NOT NULL,
  `state` varchar(30) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `card_name` varchar(30) NOT NULL,
  `card_no` int(30) NOT NULL,
  `card_ex_month` varchar(30) NOT NULL,
  `card_ex_year` int(20) NOT NULL,
  `cvv` varchar(30) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `p_id`, `user_id`, `pro_name`, `pro_image`, `pro_price`, `user_name`, `number`, `address`, `city`, `state`, `zip`, `card_name`, `card_no`, `card_ex_month`, `card_ex_year`, `cvv`, `date`) VALUES
(2, 1, 0, 'HP 15s-Fr4001TU', '/laptop/images/hp1.jpg', 56000, 'harvi123', '4567890876', 'lathi road ,collage circle , amreli-3455', 'amreli', 'Gujarat', '56782', 'sbi', 1111, 'march', 2024, '786', '2023-09-17 11:25:00'),
(3, 1, 0, 'HP 15s-Fr4001TU', '/laptop/images/hp1.jpg', 56000, 'yuvraj', '4567890876', 'vankiya,khambha,amreli,gujarat', 'amreli', 'Gujarat', '5678', 'rupay', 3333, 'march', 2024, '453', '2023-09-19 09:10:57'),
(4, 4, 1, 'HP 2', '/laptop/images/hp1.jpg', 54300, 'yuvraj', '4567890876', 'lathi road ,collage circle , amreli-3455', 'amreli', 'Gujarat', '5678', 'rupay', 4444, 'march', 2034, '121', '2023-09-19 09:15:11'),
(5, 2, 2, 'dell', '/laptop/images/dell1.jpg', 45000, 'harvi123', '4567890876', 'amreli', 'amreli', 'Gujarat', '56782', 'sbi', 3333, 'april', 2035, '543', '2023-09-19 09:16:46');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `c_id` int(25) NOT NULL,
  `p_name` varchar(25) NOT NULL,
  `p_price` int(20) NOT NULL,
  `p_image` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `c_id`, `p_name`, `p_price`, `p_image`, `date`) VALUES
(1, 1, 'HP 15s-Fr4001TU', 56000, '/laptop/images/hp1.jpg', '2023-09-11 20:07:11'),
(2, 2, 'dell', 45000, '/laptop/images/dell1.jpg', '2023-09-12 19:08:17'),
(3, 2, 'dell 2', 45000, '/laptop/images/dell1.jpg', '2023-09-12 19:18:23'),
(4, 1, 'HP 2', 54300, '/laptop/images/hp1.jpg', '2023-09-12 19:18:56'),
(5, 1, 'HP 3', 67000, '/laptop/images/hp1.jpg', '2023-09-17 09:30:21');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fullname` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(23) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fullname`, `email`, `phone`, `username`, `password`, `date`) VALUES
(1, 'yuvraj goswami  ', 'yuvraj@gmail.com', '9595945678', 'yuvraj', '8182', '2023-09-11 18:25:09'),
(2, 'Harvi Savaliaya', 'harvi@gmail.com', '9595945678', 'harvi123', '123', '2023-09-11 18:58:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
