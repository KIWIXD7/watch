<?php session_start(); require 'database/dbconnect.php'; ?>


<?php
 if($_SERVER["REQUEST_METHOD"] == "POST")
 {
   $user = trim($_POST['uname']);
   $pass = trim($_POST['pass']);
   if(isset($_POST['submit']))
   {
     
   $select_user = "SELECT * FROM `user` WHERE username='$user' And password='$pass'";
   $user_run = mysqli_query($conn,$select_user);
   if(mysqli_num_rows($user_run) == 1)
   {
       while($row = mysqli_fetch_assoc($user_run))
       {
         // session_start();
          $_SESSION['user'] = $user;
          $_SESSION['login'] = true;
          header('location:index.php');
          
       } 

   }
   else
   {
     echo "<script>alert('UserName not Exist')</script>";
   }
 }
}

require('header.php');
?>


<br><br>
<section class="contact_section ">
    <div class="container px-0">
      <div class="heading_container ">
        <h2 class="">
          Login
        </h2>
      </div>
    </div>
    <div class="container container-bg">
      <div class="row">
        
        <div class="col-md-9 col-lg-10 px-0">
          <form action="" method="post">
            
            
            <div>
              <input type="text" placeholder="Enter Username" name="uname" require/>
            </div>
            <div>
              <input type="password" placeholder="Enter Password" name="pass" require/>
            </div>
            <div class=" col-md-12">
                                <p>Create New Account <a href="signup.php">Click Here</a>
                            </div>
            <div class="d-flex">
            <button class="send" type="submit" name="submit">Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
  <br><br>
<?php require('footer.php');?>