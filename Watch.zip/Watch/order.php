
<?php session_start();
require 'database/dbconnect.php';

require 'function.php';

require 'get_data.php';

require 'header.php'; 


if(isset($_SESSION['login']) && $_SESSION['login'] == true)
{
    $login = true;
    $user=$_SESSION['user'];
    $select = "SELECT * FROM `user` Where username='$user'"; 
    $run=mysqli_query($conn,$select);
    $query_run=mysqli_fetch_assoc($run);

    $u_id=$query_run["id"];

    ?>
    <br>
<div class="container">
           <div class="heading_container heading_center"><h2>Order</h2></div>
        </div>
        <br>


        <div class="brand">
        <div class="container">

        </div>
        <div class="brand-bg">
            <div class="container">
                <div class="row">

                    <?php
                       
                     $select = "SELECT * FROM `payment` Where user_id='$u_id'";
                     $s_run=mysqli_query($conn,$select);
                    if(mysqli_num_rows($s_run))
                    {
                    while ($row = mysqli_fetch_assoc($s_run)) {
                        $id = $row['p_id'];
                        $p_name=$row['pro_name'];
                        $p_price=$row['pro_price'];
                        $p_img=$row['pro_image'];
                    
                    ?>
                    <div class="col-md-5 offset-md-1 border rounded mt-5 bg-white h-25">
        <img src="<?php echo $p_img; ?>" alt="" class="mx-2">
        <div class="pt-4">
            <h6>PRICE DETAILS</h6>
            <hr>
            <div class="row price-details">
                <div class="col-md-6">
                    <h6>Product Name:</h6>
                    
                    <hr>
                    <h6>Amount Payable</h6>
                </div>
                <div class="col-md-6">
                    <h6><?php echo $p_name; ?></h6>
                    <hr>
                    <h6><?php echo $p_price; ?></h6>
                    <form actio="index.php" method="post">
                    <button type='submit' class='btn btn-warning' name='cancle'><i class='fas fa-shopping-cart'></i>Cancle</button>         
                    <!-- <button type="submit" name="cancle">Cancle</button> -->
                </form>
                </div>
            </div>
        </div>
    </div>

    <?php
    }
}
else
{
    echo "you are not product ordered    <a href='category.php'>Order Now</a>";
}
 ?>
                     <br><br>
        
                </div>
            </div>
        </div>
    </div>
    <?php
}
else
{
    $login = false;
    ?>
    <br><br>
    <div class="jumbotron my-2">
  <h1 class="hd1">See Orders !</h1>
  <p class="lead hd1">You Are Not Logged In Please Log-in In Lapi Store</p>
  <hr class="my-4">
  <p class="lead">
    <a class="btn btn-dark btn-lg" href="Login.php" role="button">Log In</a>
    <a class="btn btn-dark  btn-lg" href="SignUp.php" role="button">Register</a>
  </p>
</div>
<br><br>
<?php 
}
?>




<?php include('footer.php') ?>


<?php


if(isset($_POST['cancle']))
{
    
    $query = "DELETE FROM payment WHERE `payment`.`user_id` = '$u_id' AND p_id='$id'";
    $RUN = mysqli_query($conn,$query);
    ?>
    <script>window.location.href="index.php";</script>
    <?php

    //header('location:index.php');
}

?>