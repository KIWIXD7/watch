<?php  require ('database/dbconnect.php');  ?>

<?php 
if($_SERVER["REQUEST_METHOD"] == "POST")
{
   $fname = $_POST["fname"];
   $email = $_POST["email"];
   $phone = $_POST["phone"];
   $user = $_POST["uname"];
   $pass = $_POST["pass"];
  if(isset($_POST["submit"])){
   if($fname == !"" && $email == !"" && $phone == !"" && $user == !"" && $pass == !"")
   {
     
       $exist = "SELECT * FROM `user` WHERE username='$user' AND password='$pass'";
       $run = mysqli_query($conn,$exist);
       if(mysqli_num_rows($run) > 0)
       {
           echo "<script>alert('UserName and Password Already Exist')</script>";
       }
       else
       {
           $query_insert = "INSERT INTO `user` (`fullname`, `email`, `phone`, `username`, `password`, `date`) VALUES ('$fname', '$email', '$phone', '$user', '$pass', current_timestamp());";
           $run_query = mysqli_query($conn, $query_insert);
           echo "<script>alert('Signup Successfully Now You Login in This website')</script>";
           echo "<script>window.location.href='login.php'</script>";
       }
     }
     else
    {
        echo "<script>alert('Your Data is Empty || Enter Your Data')</script>";
     }
   }
}





require('header.php');


?>


<br><br>
<section class="contact_section ">
    <div class="container px-0">
      <div class="heading_container ">
        <h2 class="">
          Sign Up
        </h2>
      </div>
    </div>
    <div class="container container-bg">
      <div class="row">
        
        <div class="col-md-9 col-lg-10 px-0">
          <form action="signup.php" method="post">
            <div>
              <input type="text" placeholder="Enter Full Name" name="fname" require/>
            </div>
            <div>
              <input type="email" placeholder="Enter Email" name="email" require/>
            </div>
            <div>
              <input type="text" placeholder="Enter Phone" name="phone" require/>
            </div>
            <div>
              <input type="text" placeholder="Enter Username" name="uname" require/>
            </div>
            <div>
              <input type="password" placeholder="Enter Password" name="pass" require/>
            </div>
            <div class="d-flex">
            <button class="send" type="submit" name="submit">Signup</button><br>
            </div>              
          </form>
        </div>
      </div>
    </div>
  </section>
  <br><br>
<?php require('footer.php');?>