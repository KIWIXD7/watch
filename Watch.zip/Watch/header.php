<?php if(isset($_SESSION['login']) && $_SESSION['login'] == true)
{
    $login = true;
}
else
{
    $login = false;
}  


if(isset($_SESSION['login']) && $_SESSION['login'] == true)
{
  if (isset($_POST['add'])) 
  {
   // print_r($_POST['c_id']);
    if (isset($_SESSION['cart']))
    {
      $item_array_id = array_column($_SESSION['cart'], "c_id");

       if (in_array($_POST['c_id'], $item_array_id)) 
       {
           echo "<script>alert('Product is already added in the cart..!')</script>";
           echo "<script>header('Location:index.php')</script>";
       }
       else 
       {
            $count = count($_SESSION['cart']);
            $item_array = array('c_id' => $_POST['c_id']);
            $_SESSION['cart'][$count] = $item_array;
       }
    } 
    else 
    {
       $item_array = array('c_id' => $_POST['c_id']);
       $_SESSION['cart'][0] = $item_array;
    }
  }
}
else
{
    if (isset($_POST['add']))
    {
        echo "<script>alert('login this website ')</script>";
        
    }
}
?>


<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">

  <title>
    Lappy Store
  </title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="Admin/fontawesome-free-6.1.1-web/css/all.css">

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body class="main-layout">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <nav class="navbar navbar-expand-lg custom_nav-container ">
        <a class="navbar-brand" href="index.php">
          <span>
            WATCH SHOP
          </span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class=""></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav  ">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="shop.php">
                Shop
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="category.php">
                Brand
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Order.php">
                Order
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact Us</a>
            </li>
          </ul>
          <div class="user_option">
           <?php if($login == true)
           {
              echo  "<a href='logout.php'><i class='fa fa-user' aria-hidden='true'></i><span>Logout</span></a>";
             
            }
            else
            {
                echo  "<a href='login.php'><i class='fa fa-user' aria-hidden='true'></i><span>Login</span></a>";                        
                echo  "<a href='signup.php'><i class='fa fa-user' aria-hidden='true'></i><span>Sign Up</span></a>";
             } 
            ?>

            <a href="add_to_cart.php">Cart
            <?php
                                                    if (isset($_SESSION['cart'])) {
                                                        $count = count($_SESSION['cart']);
                                                        echo "<span id='cart_count' class='text-black'>$count</span>";
                                                    } else {
                                                        echo "<span id=\"cart_count\" class=\"text-black\">(0)</span>";
                                                    }
                                                    ?>
              <i class="fa fa-shopping-bag" aria-hidden="true"></i>
            </a>
            <form class="form-inline ">
              <button class="btn nav_search-btn" type="submit">
              
              </button>
            </form>
          </div>
        </div>
      </nav>
    </header>
    <!-- end header section -->