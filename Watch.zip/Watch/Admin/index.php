<?php
session_start();



 if(!isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
{
    
    header('location:login.php');
}
else
{
    $login = false;
    
}  
?>
<!DOCTYPE html>
<!--=== Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="style.css">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title>Admin Dashboard Panel</title> 
</head>
<body>
 <?php require('header.php'); ?>

         <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="uil uil-tachometer-fast-alt"></i>
                    <span class="text">Dashboard</span>
                </div>

               <div class="boxes">
                    <div class="box box1">
                    <i class="fa-solid fa-thumbs-up"></i>
                        <div class="card-body">Category Table</div>
                        <br><br>
                        <a class="small text-white stretched-link" href="category.php">View Details</a>
                    </div>
                    <div class="box box2">
                    <i class="fa-duotone fa-thumbs-up"></i>
                        <div class="card-body">User Table</div>
                        <br><br>
                        <a class="small text-white stretched-link" href="mainuser.php">View Details</a>
                    </div>
                    <div class="box box3">
                    <i class="fa-solid fa-plus"></i>    
                        <div class="card-body">Product Table</div>
                        <br><br>
                        <a class="small text-white stretched-link" href="product.php">View Details</a>
                    </div>
                </div>
            </div>


    <script src="script.js"></script>
</body>
</html>