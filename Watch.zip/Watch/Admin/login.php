<?php
  //showe on alert box error and success
 $login = false;
 $showerror = false;

 if($_SERVER["REQUEST_METHOD"] == "POST")
 {
   include 'database/_dbconnect.php';
   $adminname=$_POST['adminname'];
   $password=$_POST['password'];
   $exists=false;
  
   
        // $query = "SELECT * FROM `users` WHERE username='$username' and password='$password'";
        $query = "SELECT * FROM `admin` WHERE adminname='$adminname' and password='$password'";
        $run = mysqli_query($conn,$query);
        $num = mysqli_num_rows($run);
        if($num == 1)
        {
            while($row=mysqli_fetch_assoc($run)){
                if(isset($_POST['submit']))
                {
                    $login = true;
                    session_start();
                    $_SESSION['adminname'] = $username;
                    $_SESSION['loggedin'] = true;
                    header('location:index.php');

                }
                else
                {
                    echo "<script>alert('Password was wong entare prafact password')</script>";
                }
            }
        }
       else
       {
        echo "<script>alert('Password was wong entare prafact password')</script>";      
       }
 }
   
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laptop</title>
  <!--resposive css-->
  <link rel="stylesheet" media="screen and (max-width:1170px)" href="./css/phone.css">

  <!--bootstrap css-->
  <!-- <link rel="stylesheet" href="bootstrap-5.1.3-dist/css/bootstrap.min.css"> -->
  <link rel="stylesheet" type="text/css" href="mycss.css">
  <!--font awesome-->
  <link rel="stylesheet" href="fontawesome-free-6.1.1-web/css/all.css">

</head>
<body>
<div class="login-form" style="margin-top:240px;">
    <h2>WATCH ADMIN LOGIN</h2>
    <form action="" method="post">
        <div class="input-field">
            <i class="bi bi-person-circle"></i>
            <input type="text" placeholder="Username" name="adminname">
        </div>
        <div class="input-field">
            <i class="bi bi-shield-lock"></i>
            <input type="password" placeholder="Password" name="password">
        </div>
        
        <button type="submit" name="submit">Login</button>


    </form>
</div>
    </div>
</body>
</html>