<?php
 if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true)
{
    
    $login = true;
}
else
{
    $login = false;
    header('location:login.php');
}  
?>

<!--=== Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="style.css">
    <link href="fontawesome-free-6.1.1-web/css/all.css" rel="stylesheet">
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title>Admin Dashboard Panel</title> 
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <!-- <img src="images/logo.png" alt=""> -->
            </div>

            <span class="logo_name">Watch Store</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="index.php">
                    <i class="fa fa-light fa-house"></i>
                    <span class="link-name">Dahsboard</span>
                </a></li>
                <li><a href="category.php">
                <i class="fa-solid fa-thumbs-up"></i>
                    <span class="link-name">Category</span>
                </a></li>
                <li><a href="product.php">
                    <i class="fa-solid fa-plus"></i>
                    <span class="link-name">product</span>
                </a></li>
                <li><a href="mainuser.php">
                <i class="fa-duotone fa-thumbs-up"></i>
                    <span class="link-name">User Manage</span>
                </a></li>
                <li><a href="order.php">
                    <i class="fa fa-duotone fa-cart-plus" ></i>
                    <span class="link-name">Order</span>
                </a></li>
             
            </ul>
            
            <ul class="logout-mode">
                <li><a href="logout.php">
                    <i class="fa fa-solid fa-right-from-bracket"></i>
                    <span class="link-name">Logout</span>

                </a></li>

             
            </ul>
        </div>
    </nav>

     <section class="dashboard">
        <div class="top">
            <i class="fa fa-bars"></i>

            <div class="search-box">
                <i class="uil uil-search"></i>
                
            </div>
            
           
        </div>

		
		<script src="script.js"></script>
</body>
</html>





















