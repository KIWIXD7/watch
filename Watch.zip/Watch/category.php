<?php session_start(); require 'database/dbconnect.php'; 
require 'function.php';

require 'get_data.php';

require('header.php');
?>
<section class="shop_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          Brand
        </h2>
      </div>
      <div class="brand">
        <div class="container">
        </div>
        <div class="brand-bg">
            <div class="container">
                <div class="row">

                    <?php

                    $run = cat_getData();

                    while ($row = mysqli_fetch_assoc($run)) {
                        get_category($row['name'], $row['image'], $row['id']);
                    }
                    ?>
                 
                </div>
            </div>
        </div>
    </div>
    <div class="btn-box">
        <a href="">
          View All Products
        </a>
      </div>
        </div>
     
</div>
</section>


<?php require('footer.php');?>