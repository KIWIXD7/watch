<?php 
  session_start();
 // database folder
require 'database/dbconnect.php';

//product showing function call(get_data file)
require_once('get_data.php');

//user login true or false checke
if (isset($_SESSION['login']) && $_SESSION['login'] == true) {
    $loggedin = true;
    $uname = $_SESSION['user'];
} else {
    $loggedin = false;
}

//   product id get on image through
$product = $_GET['id'];
// echo $product;
$item_p = getData();
foreach ($item_p as $p) :
    if ($p['id'] == $product) :
        $name =  $p['p_name'];
        $price = $p['p_price'];
        $image = $p['p_image'];
    endif;
endforeach;

include('header.php');


?>

<link href='css/checkoutstyle.css' rel='stylesheet' />

<section class="shop_section layout_padding">
 
        <div class="container">
           <div class="heading_container heading_center"><h2>Payment</h2></div>
        </div>
    


    <div class="col-md-5 offset-md-1 border rounded mt-5 bg-black h-25" style="background-color:#eeeeee;">
        <img src="<?php echo $image; ?>" alt="" class="mx-2">
        <div class="pt-4">
            <h6>PRICE DETAILS</h6>
            <hr>
            <div class="row price-details">
                <div class="col-md-6">
                    <h6>Product Name:</h6>
                    <h6>Delivery Charges</h6>
                    <hr>
                    <h6>Amount Payable</h6>
                </div>
                <div class="col-md-6">
                    <h6><?php echo $name; ?></h6>
                    <h6 class="text-success">FREE</h6>
                    <hr>
                    <h6><?php echo $price; ?></h6>
                </div>
            </div>
        </div>
    </div>
<br>
   
    
<div class="row">
  <div class="col-75">
    <div class="container">
      <form action="" method="POST">
      
                    <div>
                            <input type="hidden" name="p_name" id="p_name" value="<?php echo $name; ?>">
                            <input type="hidden" name="p_price" id="p_price" value="<?php echo $price; ?>">
                            <input type="hidden" name="p_image" id="p_image" value="<?php echo $image; ?>">
                        </div>
        <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> User Name</label>
            <input type="text" id="fname" name="name" placeholder="John M. Doe" require>
            <label for="email"><i class="fa fa-envelope"></i> Number</label>
            <input type="text" id="number" name="number" placeholder="Enter Mobile No" require>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="542 W. 15th Street" require>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" placeholder="New York" require>

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                <input type="text" id="state" name="state" placeholder="NY" require>
              </div>
              <div class="col-50">
                <label for="zip">Zip</label>
                <input type="text" id="zip" name="zip" placeholder="10001" require>
              </div>
            </div>
          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="John More Doe" require>
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444" require>
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September" require>
            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018" require>
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352"  require>
              </div>
            </div>
          </div>
          
        </div>
        <label>
          <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
        </label>
        <input type="submit" value="Continue to checkout" class="btn" name="submit">
      </form>
    </div>
  </div>

  </section>
  <footer class=" footer_section">
      <div class="container">
        <p>
          &copy; <span id="displayYear"></span> All Rights Reserved By
          <a href="/Admin/login.php">MCA(LJ COLLAGE) ADMIN</a>
        </p>
      </div>
    </footer>


    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    //user 
    // echo $_POST['cardname'];
    $u_query = "SELECT id,username FROM user WHERE username='$uname'";
    $u_run = mysqli_query($conn, $u_query);
    $u_row = mysqli_fetch_assoc($u_run);
    $u_id = $u_row['id'];
    if ($u_id == $u_id)
        //  product information
    $product;
    $p_name = $_POST['p_name'];
    $p_image = $_POST['p_image'];
    $p_price = $_POST['p_price'];
    //user informatio
    $u_id;
    $name = $_POST['name'];
    $phone_number = $_POST['number'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zipcode = $_POST['zip'];

   

    if (isset($_POST['submit'])) 
    {

        if ($loggedin == true)
         {
            if ($name == !"" && $phone_number == !"" &&  $address == !"" && $city == !"" && $state == !"" && $zipcode == !"") 
            {
                $card_name  = $_POST['cardname'];
                $card_number = $_POST['cardnumber'];
                $card_ex_month  = $_POST['expmonth'];
                $card_ex_year  = $_POST['expyear'];
                $card_cvv = $_POST['cvv'];

                if ($card_name == !"" && $card_number == !"" && $card_ex_month == !"" && $card_ex_year == !"" && $card_cvv == !"") 
                {
                     
                   $b_query="INSERT INTO `payment`(`p_id`, `user_id`, `pro_name`, `pro_image`, `pro_price`, `user_name`, `number`, `address`, `city`, `state`, `zip`, `card_name`, `card_no`, `card_ex_month`, `card_ex_year`, `cvv`, `date`) VALUES 
                       ('$product','$u_id','$p_name','$p_image','$p_price','$name','$phone_number','$address','$city','$state','$zipcode',
                       '$card_name','$card_number','$card_ex_month','$card_ex_year','$card_cvv',current_timestamp())";
                     //echo $b_query;
                        $b_run = mysqli_query($conn, $b_query);
                    if ($b_run)
                    {
                        echo "<script>alert('You Pay $p_price in $p_name product')</script>";
                    } 
                    else 
                    {
                        echo "<script>alert('You Payment is Fail')</script>";
                    }
                } 
                else 
                {
                    echo "<script>alert('Your Crad Details must be enter')</script>";
                }
            } 
            else 
            {
                echo "<script>alert('Your Data  Empty')</script>";
            }
        }
        else 
        {
            echo "<script>alert('Login in This website')</script>";
        }
    }
}

?>