<?php session_start(); require 'database/dbconnect.php'; 
require 'function.php';

require 'get_data.php';

require('header.php');
?>
<section class="shop_section layout_padding">
  <div class="brand">
        <div class="container">
          
        <div class="heading_container heading_center">
        <h2>
          Latest Products
        </h2>
      </div>
     
        </div>
        <div class="brand-bg">
            <div class="container">
                <div class="row">
                
                <?php


                        $run = getData();
                        while ($row = mysqli_fetch_assoc($run)) 
                        {
                            component($row['p_name'], $row['p_price'], $row['p_image'], $row['id']);
                        }

                         echo "<br>";
                 ?>
                
                </div>
                <div class="btn-box">
        <a href="">View All Products</a>
      </div>
            </div>
        </div>
    </div>
    </div>
 </section>


<?php require('footer.php');?>